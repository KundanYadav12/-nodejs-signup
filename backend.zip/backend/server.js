import app from "./app.js";

app.listen(process.env.PORT,()=>{
    console.log(`server Running On Port ${process.env.PORT}`)
})